<?php
if ( !defined( 'FW' ) ) {
	die( 'Forbidden' );
}
?>
<div class="xs-code">
	<?php echo modular_return( $atts[ 'text' ] ); ?>
</div>
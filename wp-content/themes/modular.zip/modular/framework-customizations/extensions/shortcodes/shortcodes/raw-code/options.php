<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'text' => array(
		'type'  => 'textarea',
		'value' => '',
		'label' => __( 'Code', 'modular' ),
		'desc'  => __( 'Enter the HTML code', 'modular' )
	),
	
);
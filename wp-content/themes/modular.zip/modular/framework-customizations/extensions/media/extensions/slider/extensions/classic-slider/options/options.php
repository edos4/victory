<?php

if (!defined('FW'))
    die('Forbidden');
/*
 * options.php - extra options shown after default options on add and edit slider page.
 */
$options = array(
    'unique_id' => array(
        'type' => 'unique'
    ),
);

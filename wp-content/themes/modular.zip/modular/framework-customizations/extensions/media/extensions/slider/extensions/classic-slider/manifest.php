<?php

$manifest['standalone'] = true;

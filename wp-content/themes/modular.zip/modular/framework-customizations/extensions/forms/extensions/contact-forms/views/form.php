<?php
if (!defined('FW'))
    die('Forbidden');
/**
 * @var string $form_html
 */
?>
<div class="fw-contact-form" id="fancy-inputs">
    <div class="fw-row placeholder-light" data-wow-offset="10" data-wow-duration="1.55s">
        <?php echo  $form_html; ?>
    </div>
</div>